var O=Object.defineProperty;var $=(g,u,b)=>u in g?O(g,u,{enumerable:!0,configurable:!0,writable:!0,value:b}):g[u]=b;var h=(g,u,b)=>$(g,typeof u!="symbol"?u+"":u,b);(function(){"use strict";const g=[/doubleclick\.net/i,/googlesyndication\.com/i,/googleadservices\.com/i,/criteo\.(com|net)/i,/taboola\.com/i,/outbrain\.com/i,/teads\.tv/i,/onetag-sys\.com/i,/2mdn\.net/i,/adnxs\.com/i,/rubiconproject\.com/i,/pubmatic\.com/i,/openx\.net/i,/casalemedia\.com/i,/smartadserver\.com/i,/adform\.net/i,/scorecardresearch\.com/i,/advertising\.com/i,/amazon-adsystem\.com/i,/adservice/i,/adsystem/i,/adserver/i,/tracking/i,/telemetry/i,/pixel/i,/beacon/i,/analytics/i,/sponsor/i],u=["adsbygoogle","ad-slot","ad-container","advertisement","banner-ad","sponsor-slot","taboola-container","outbrain-widget","dfp-ad","publicidade","patrocinado","anuncio","propaganda","adserver","banner","ad-wrapper","ad-unit","native-ad"],b=[{width:300,height:250},{width:728,height:90},{width:160,height:600},{width:300,height:600},{width:970,height:250},{width:320,height:50},{width:320,height:100}],P=new Set(["com.br","net.br","org.br","gov.br","edu.br","co.uk","org.uk","me.uk","com.au","net.au","co.nz","co.jp"]);function E(r){if(!r||typeof r!="string")return null;const t=r.trim();if(!t||t.startsWith("javascript:")||t.startsWith("about:")||t.startsWith("data:")||!t.includes("://")&&!t.includes(".")&&!t.startsWith("localhost"))return null;try{let i=t;i.startsWith("//")?i=`https:${i}`:i.includes("://")||(i=`https://${i}`);const e=new URL(i);return!e.hostname||!e.hostname.includes(".")&&e.hostname!=="localhost"?null:e.hostname.toLowerCase()}catch{return null}}function y(r){const t=r.toLowerCase().split(".");if(t.length<=2)return r.toLowerCase();const i=`${t[t.length-2]}.${t[t.length-1]}`;return P.has(i)&&t.length>=3?`${t[t.length-3]}.${i}`:`${t[t.length-2]}.${t[t.length-1]}`}function M(r,t){const i=y(r),e=y(t);return i!==e}function k(r){return g.some(t=>t.test(r))}function A(r,t){return b.some(i=>Math.abs(i.width-r)<=5&&Math.abs(i.height-t)<=5)}function D(r){const t=r.toLowerCase();return u.some(i=>t.includes(i))}function x(r){const t=[];let i=r;for(;i&&t.length<8;)t.push(`${i.tagName.toLowerCase()}#${i.id||""}.${[...i.classList].slice(0,3).join(".")}`),i=i.parentElement;let e=0;for(const o of t.join(">").split(""))e=(e<<5)-e+o.charCodeAt(0),e|=0;return String(e)}function C(r,t,i,e){const o=E(r);if(!o)return null;const s=y(o),l=M(o,t);if(!l&&i!=="user_inspector_click")return null;const a=[];let n=10,d=l?"third_party":"site_asset";l&&(a.push("Third-party resource outside main page domain"),n+=20),(k(r)||k(o))&&(a.push("Matches known ad-network or tracking pattern"),n+=45,d="ads"),a.push("Dynamically injected into DOM via JavaScript"),n+=20,d==="third_party"&&(d="ads"),e!=null&&e.initiatorScript&&(a.push(`Injected by script: ${e.initiatorScript}`),n+=15),e!=null&&e.classOrId&&D(e.classOrId)&&(a.push(`Container attributes indicate advertisement (${e.classOrId})`),n+=25,d="ads"),e!=null&&e.width&&(e!=null&&e.height)&&A(e.width,e.height)&&(a.push(`Element dimensions match standard IAB ad banner (${e.width}x${e.height})`),n+=20,d="ads"),n=Math.min(100,n);let p="low";return n>=70?p="high":n>=30&&(p="medium"),{candidateId:`cand-${Date.now()}-${Math.random().toString(36).substring(2,7)}`,target:s,category:d,score:n,riskLevel:p,reasons:a,evidence:{url:r,source:i,resourceType:(e==null?void 0:e.elementTag)||"unknown",isThirdParty:l,elementTag:e==null?void 0:e.elementTag,initiatorScript:e==null?void 0:e.initiatorScript,domPathHash:e==null?void 0:e.domPathHash,elementId:e==null?void 0:e.elementId,elementClasses:e==null?void 0:e.elementClasses,dimensions:e!=null&&e.width&&(e!=null&&e.height)?{width:e.width,height:e.height}:void 0,timestamp:Date.now()}}}class I{constructor(t){h(this,"active",!1);h(this,"modalOpen",!1);h(this,"backdrop",null);h(this,"cancelBar",null);h(this,"highlightBox",null);h(this,"tooltip",null);h(this,"reviewDialog",null);h(this,"pageContext");h(this,"originalWindowOpen",null);h(this,"neutralizedElements",[]);this.pageContext=t,this.onMouseMove=this.onMouseMove.bind(this),this.onContextMenu=this.onContextMenu.bind(this),this.onKeyDown=this.onKeyDown.bind(this),this.onCapturePointerEvent=this.onCapturePointerEvent.bind(this),this.onCaptureClick=this.onCaptureClick.bind(this)}start(){if(!this.active){this.active=!0,this.modalOpen=!1,this.originalWindowOpen=window.open;try{window.open=()=>(console.warn("[YAPD Sentinel] Popup bloqueado preventivamente durante o modo de inspeção."),null)}catch{}this.createDomElements(),this.attachCaptureListeners(),this.showToast("🎯 YAPD Sentinel: Clique no anúncio para revisar e bloquear (ESC para cancelar).")}}stop(){if(!(!this.active&&!this.modalOpen)){if(this.active=!1,this.modalOpen=!1,this.originalWindowOpen){try{window.open=this.originalWindowOpen}catch{}this.originalWindowOpen=null}this.restoreNeutralizedElements(),this.detachCaptureListeners(),document.removeEventListener("keydown",this.onKeyDown,!0),this.removeDomElements()}}attachCaptureListeners(){window.addEventListener("pointerdown",this.onCapturePointerEvent,!0),window.addEventListener("mousedown",this.onCapturePointerEvent,!0),window.addEventListener("pointerup",this.onCapturePointerEvent,!0),window.addEventListener("mouseup",this.onCapturePointerEvent,!0),window.addEventListener("auxclick",this.onCapturePointerEvent,!0),window.addEventListener("dblclick",this.onCapturePointerEvent,!0),window.addEventListener("click",this.onCaptureClick,!0),window.addEventListener("contextmenu",this.onContextMenu,!0),document.addEventListener("keydown",this.onKeyDown,!0)}detachCaptureListeners(){window.removeEventListener("pointerdown",this.onCapturePointerEvent,!0),window.removeEventListener("mousedown",this.onCapturePointerEvent,!0),window.removeEventListener("pointerup",this.onCapturePointerEvent,!0),window.removeEventListener("mouseup",this.onCapturePointerEvent,!0),window.removeEventListener("auxclick",this.onCapturePointerEvent,!0),window.removeEventListener("dblclick",this.onCapturePointerEvent,!0),window.removeEventListener("click",this.onCaptureClick,!0),window.removeEventListener("contextmenu",this.onContextMenu,!0)}onCapturePointerEvent(t){!this.active||this.modalOpen||(t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation())}onCaptureClick(t){if(!this.active||this.modalOpen||(t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation(),t.button!==0))return;const i=this.pickElementFromPoint(t.clientX,t.clientY);i&&this.selectAndReviewElement(i)}createDomElements(){if(this.backdrop)return;this.backdrop=document.createElement("div"),this.backdrop.id="yapd-sentinel-backdrop",Object.assign(this.backdrop.style,{position:"fixed",inset:"0",width:"100vw",height:"100vh",zIndex:"2147483645",cursor:"crosshair",pointerEvents:"auto",backgroundColor:"transparent"}),this.highlightBox=document.createElement("div"),this.highlightBox.id="yapd-sentinel-highlight",Object.assign(this.highlightBox.style,{position:"fixed",zIndex:"2147483646",pointerEvents:"none",border:"2px dashed #ef4444",backgroundColor:"rgba(239, 68, 68, 0.18)",boxShadow:"0 0 0 9999px rgba(0, 0, 0, 0.15)",transition:"all 0.05s ease-out",display:"none"}),this.tooltip=document.createElement("div"),this.tooltip.id="yapd-sentinel-tooltip",Object.assign(this.tooltip.style,{position:"fixed",zIndex:"2147483647",pointerEvents:"none",padding:"6px 12px",background:"#18181b",color:"#ffffff",fontSize:"12px",fontFamily:"system-ui, -apple-system, sans-serif",fontWeight:"500",borderRadius:"6px",boxShadow:"0 4px 14px rgba(0,0,0,0.5)",border:"1px solid #3f3f46",display:"none"}),this.backdrop.addEventListener("mousemove",this.onMouseMove),this.cancelBar=document.createElement("div"),this.cancelBar.id="yapd-sentinel-cancel-bar",Object.assign(this.cancelBar.style,{position:"fixed",top:"16px",left:"50%",transform:"translateX(-50%)",zIndex:"2147483647",backgroundColor:"#18181b",color:"#f4f4f5",padding:"8px 16px",borderRadius:"9999px",boxShadow:"0 10px 25px -5px rgba(0, 0, 0, 0.7), 0 0 0 1px #3f3f46",display:"flex",alignItems:"center",gap:"12px",fontFamily:"-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",fontSize:"13px",fontWeight:"500",pointerEvents:"auto"});const t=document.createElement("span");t.textContent="🎯 Modo Inspecionar Ad Ativo";const i=document.createElement("button");i.id="yapd-btn-cancel-bar",i.textContent="✕ Cancelar (ESC)",Object.assign(i.style,{backgroundColor:"#ef4444",color:"#ffffff",border:"none",borderRadius:"9999px",padding:"4px 12px",fontSize:"12px",fontWeight:"600",cursor:"pointer",transition:"background-color 0.15s ease"}),i.addEventListener("mouseenter",()=>{i.style.backgroundColor="#dc2626"}),i.addEventListener("mouseleave",()=>{i.style.backgroundColor="#ef4444"}),i.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),this.stop(),this.showToast("Inspetor cancelado.")}),this.cancelBar.appendChild(t),this.cancelBar.appendChild(i),document.documentElement.appendChild(this.backdrop),document.documentElement.appendChild(this.highlightBox),document.documentElement.appendChild(this.tooltip),document.documentElement.appendChild(this.cancelBar)}removeDomElements(){var t,i,e;if(this.backdrop&&(this.backdrop.removeEventListener("mousemove",this.onMouseMove),this.backdrop.remove(),this.backdrop=null),(t=this.cancelBar)==null||t.remove(),this.cancelBar=null,(i=this.highlightBox)==null||i.remove(),this.highlightBox=null,(e=this.tooltip)==null||e.remove(),this.tooltip=null,this.reviewDialog){try{this.reviewDialog.close()}catch{}this.reviewDialog.remove(),this.reviewDialog=null}}restoreNeutralizedElements(){for(const t of this.neutralizedElements)try{t.pointerEvents?t.el.style.pointerEvents=t.pointerEvents:t.el.style.removeProperty("pointer-events"),t.zIndex?t.el.style.zIndex=t.zIndex:t.el.style.removeProperty("z-index"),t.opacity?t.el.style.opacity=t.opacity:t.el.style.removeProperty("opacity")}catch{}this.neutralizedElements=[]}pickElementFromPoint(t,i){return document.elementsFromPoint(t,i).find(s=>s!==this.backdrop&&s!==this.cancelBar&&!s.closest("#yapd-sentinel-cancel-bar")&&s!==this.highlightBox&&s!==this.tooltip&&s!==this.reviewDialog&&!s.closest("#yapd-sentinel-dialog")&&!s.classList.contains("yapd-sentinel-toast")&&s!==document.documentElement&&s!==document.body)||null}onMouseMove(t){if(!this.active||this.modalOpen||!this.backdrop||!this.highlightBox||!this.tooltip)return;const i=this.pickElementFromPoint(t.clientX,t.clientY);if(!i){this.highlightBox.style.display="none",this.tooltip.style.display="none";return}const e=i.getBoundingClientRect();Object.assign(this.highlightBox.style,{display:"block",top:`${e.top}px`,left:`${e.left}px`,width:`${e.width}px`,height:`${e.height}px`});const o=i.tagName.toLowerCase(),s=`${Math.round(e.width)}x${Math.round(e.height)}`;e.width>=window.innerWidth*.75&&e.height>=window.innerHeight*.75&&(window.getComputedStyle(i).position==="fixed"||window.getComputedStyle(i).position==="absolute")?(this.tooltip.textContent=`🚨 [Overlay Invasivo Detectado] <${o}> ${s} (Clique para bloquear ou remover)`,this.highlightBox.style.borderColor="#f59e0b",this.highlightBox.style.backgroundColor="rgba(245, 158, 11, 0.25)"):(this.tooltip.textContent=`🎯 <${o}> ${s} (Clique para revisar e bloquear)`,this.highlightBox.style.borderColor="#ef4444",this.highlightBox.style.backgroundColor="rgba(239, 68, 68, 0.18)");const a=e.top>=36?e.top-32:e.bottom+8,n=Math.max(8,Math.min(e.left,window.innerWidth-300));Object.assign(this.tooltip.style,{display:"block",top:`${a}px`,left:`${n}px`})}selectAndReviewElement(t){this.modalOpen=!0,this.detachCaptureListeners(),document.addEventListener("keydown",this.onKeyDown,!0),this.backdrop&&(this.backdrop.remove(),this.backdrop=null),this.cancelBar&&(this.cancelBar.remove(),this.cancelBar=null),this.tooltip&&(this.tooltip.remove(),this.tooltip=null);let i=t;for(;i&&i!==document.body&&i!==document.documentElement;){this.neutralizedElements.push({el:i,pointerEvents:i.style.pointerEvents,zIndex:i.style.zIndex,opacity:i.style.opacity});try{i.style.setProperty("pointer-events","none","important"),i.style.setProperty("z-index","0","important"),i.style.setProperty("opacity","0.3","important")}catch{}i=i.parentElement}const e=this.extractUrlsFromElement(t),o=[];for(const l of e){const a=E(l);if(a){const n=y(a);n&&!o.includes(n)&&o.push(n)}}const s=t.getAttribute("data-yaps-origin");if(s){const l=E(s);if(l){const a=y(l);a&&!o.includes(a)&&o.push(a)}}this.openReviewDialogTopLayer(t,o)}ensureDialogStylesInjected(){if(document.getElementById("yapd-sentinel-dialog-styles"))return;const t=document.createElement("style");t.id="yapd-sentinel-dialog-styles",t.textContent=`
      dialog#yapd-sentinel-dialog {
        all: initial !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        position: fixed !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        margin: 0 !important;
        padding: 24px !important;
        width: min(480px, calc(100vw - 32px)) !important;
        max-width: 480px !important;
        background: #18181b !important;
        color: #f4f4f5 !important;
        border-radius: 12px !important;
        border: 1px solid #3f3f46 !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 0 1px #27272a !important;
        display: block !important;
        z-index: 2147483647 !important;
        box-sizing: border-box !important;
      }
      dialog#yapd-sentinel-dialog::backdrop {
        background: rgba(0, 0, 0, 0.8) !important;
        backdrop-filter: blur(4px) !important;
      }
      #yapd-sentinel-dialog * {
        box-sizing: border-box !important;
        font-family: inherit !important;
      }
      #yapd-sentinel-dialog .dialog-header {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        margin-bottom: 16px !important;
      }
      #yapd-sentinel-dialog .dialog-title {
        font-size: 16px !important;
        font-weight: 600 !important;
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
        color: #ffffff !important;
      }
      #yapd-sentinel-dialog .btn-close {
        background: transparent !important;
        border: none !important;
        color: #a1a1aa !important;
        cursor: pointer !important;
        font-size: 18px !important;
        padding: 4px 8px !important;
        border-radius: 6px !important;
        transition: background 0.15s !important;
      }
      #yapd-sentinel-dialog .btn-close:hover {
        background: #27272a !important;
        color: #ffffff !important;
      }
      #yapd-sentinel-dialog .overlay-banner {
        background: rgba(245, 158, 11, 0.15) !important;
        border: 1px solid rgba(245, 158, 11, 0.4) !important;
        border-radius: 8px !important;
        padding: 10px 12px !important;
        margin-bottom: 14px !important;
        font-size: 12px !important;
        color: #fbbf24 !important;
        line-height: 1.4 !important;
      }
      #yapd-sentinel-dialog .element-preview {
        background: #27272a !important;
        border-radius: 8px !important;
        padding: 12px !important;
        margin-bottom: 16px !important;
        font-size: 12px !important;
        border: 1px solid #3f3f46 !important;
      }
      #yapd-sentinel-dialog .element-label {
        color: #a1a1aa !important;
        font-size: 11px !important;
        text-transform: uppercase !important;
        letter-spacing: 0.05em !important;
        margin-bottom: 4px !important;
      }
      #yapd-sentinel-dialog .element-tag {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
        color: #f43f5e !important;
        font-weight: 600 !important;
      }
      #yapd-sentinel-dialog .element-id-class {
        color: #a1a1aa !important;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
        font-size: 11px !important;
        margin-top: 2px !important;
        word-break: break-all !important;
      }
      #yapd-sentinel-dialog .form-group {
        margin-bottom: 18px !important;
      }
      #yapd-sentinel-dialog .form-label {
        display: block !important;
        font-size: 12px !important;
        font-weight: 500 !important;
        color: #d4d4d8 !important;
        margin-bottom: 6px !important;
      }
      #yapd-sentinel-dialog .input-text,
      #yapd-sentinel-dialog .select-domain {
        width: 100% !important;
        background: #09090b !important;
        border: 1px solid #3f3f46 !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        padding: 9px 12px !important;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
        font-size: 13px !important;
        outline: none !important;
      }
      #yapd-sentinel-dialog .input-text:focus,
      #yapd-sentinel-dialog .select-domain:focus {
        border-color: #ef4444 !important;
      }
      #yapd-sentinel-dialog .actions-bar {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 10px !important;
        margin-top: 20px !important;
      }
      #yapd-sentinel-dialog .btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 6px !important;
        padding: 9px 16px !important;
        border-radius: 8px !important;
        font-size: 13px !important;
        font-weight: 500 !important;
        cursor: pointer !important;
        border: none !important;
        transition: all 0.15s !important;
      }
      #yapd-sentinel-dialog .btn-cancel {
        background: transparent !important;
        border: 1px solid #3f3f46 !important;
        color: #d4d4d8 !important;
      }
      #yapd-sentinel-dialog .btn-cancel:hover {
        background: #27272a !important;
        color: #ffffff !important;
      }
      #yapd-sentinel-dialog .btn-remove {
        background: #27272a !important;
        border: 1px solid #ef4444 !important;
        color: #f87171 !important;
      }
      #yapd-sentinel-dialog .btn-remove:hover {
        background: rgba(239, 68, 68, 0.2) !important;
        color: #ffffff !important;
      }
      #yapd-sentinel-dialog .btn-block {
        background: #dc2626 !important;
        color: #ffffff !important;
        font-weight: 600 !important;
      }
      #yapd-sentinel-dialog .btn-block:hover {
        background: #b91c1c !important;
      }
      #yapd-sentinel-dialog .btn:disabled {
        opacity: 0.6 !important;
        cursor: not-allowed !important;
      }
    `,(document.head||document.documentElement).appendChild(t)}openReviewDialogTopLayer(t,i){this.reviewDialog&&(this.reviewDialog.remove(),this.reviewDialog=null),this.ensureDialogStylesInjected();const e=t.tagName.toLowerCase(),o=t.getBoundingClientRect(),s=i[0]||"",l=o.width>=window.innerWidth*.75&&o.height>=window.innerHeight*.75&&(window.getComputedStyle(t).position==="fixed"||window.getComputedStyle(t).position==="absolute"),a=document.createElement("dialog");a.id="yapd-sentinel-dialog",a.innerHTML=`
      <div class="dialog-header">
        <div class="dialog-title">
          <span>🎯</span>
          <span>YAPD Sentinel - Revisar Alvo</span>
        </div>
        <button class="btn-close" id="yapd-btn-close" title="Fechar">✕</button>
      </div>

      ${l?`
        <div class="overlay-banner">
          🚨 <strong>Overlay Invasivo Detectado:</strong> Este elemento cobria a tela. Seus cliques foram neutralizados. Você pode bloqueá-lo no Pi-hole ou removê-lo da página agora.
        </div>
      `:""}

      <div class="element-preview">
        <div class="element-label">Elemento Inspecionado</div>
        <div class="element-tag">&lt;${e}&gt; (${Math.round(o.width)}x${Math.round(o.height)}px)</div>
        ${t.id?`<div class="element-id-class">#${t.id}</div>`:""}
        ${t.className&&typeof t.className=="string"?`<div class="element-id-class">.${t.className.trim().split(/\s+/).slice(0,5).join(".")}</div>`:""}
      </div>

      <div class="form-group">
        <label class="form-label">Domínio para Bloquear no Pi-hole:</label>
        ${i.length>1?`
          <select class="select-domain" id="yapd-select-domain">
            ${i.map(m=>`<option value="${m}">${m}</option>`).join("")}
          </select>
        `:`
          <input class="input-text" id="yapd-input-domain" type="text" value="${s}" placeholder="ex: adnetwork.com" />
        `}
        ${i.length===0?'<div style="color: #a1a1aa; font-size: 11px; margin-top: 6px;">Nenhum domínio explícito encontrado nos atributos. Digite o domínio acima ou remova o elemento invasivo da tela.</div>':""}
      </div>

      <div class="actions-bar">
        <button class="btn btn-remove" id="yapd-btn-remove" title="Remove este elemento do HTML para destravar a navegação imediatamente">
          <span>🗑️</span>
          <span>Remover da tela</span>
        </button>

        <div style="display: flex; gap: 8px;">
          <button class="btn btn-cancel" id="yapd-btn-cancel">Cancelar</button>
          <button class="btn btn-block" id="yapd-btn-block">
            <span>🛡️</span>
            <span>Bloquear no Pi-hole</span>
          </button>
        </div>
      </div>
    `,(document.body||document.documentElement).appendChild(a),this.reviewDialog=a;try{a.showModal()}catch{a.setAttribute("open","")}a.addEventListener("cancel",m=>{m.preventDefault(),this.stop()});const n=a.querySelector("#yapd-btn-close"),d=a.querySelector("#yapd-btn-cancel"),p=a.querySelector("#yapd-btn-remove"),c=a.querySelector("#yapd-btn-block"),f=m=>{m.preventDefault(),m.stopPropagation(),this.stop()};n==null||n.addEventListener("click",f),d==null||d.addEventListener("click",f),p==null||p.addEventListener("click",m=>{m.preventDefault(),m.stopPropagation();try{t.remove(),this.showToast("🗑️ Elemento removido da página com sucesso!")}catch{t.style.setProperty("display","none","important"),this.showToast("🗑️ Elemento ocultado com sucesso!")}this.stop()}),c==null||c.addEventListener("click",async m=>{m.preventDefault(),m.stopPropagation();let w=s;const S=a.querySelector("#yapd-select-domain"),L=a.querySelector("#yapd-input-domain");if(S?w=S.value:L&&(w=L.value.trim()),!w){alert("Por favor, informe um domínio para bloquear.");return}c.disabled=!0,c.textContent="Bloqueando no Pi-hole...",typeof chrome<"u"&&chrome.runtime?chrome.runtime.sendMessage({type:"QUICK_BLOCK_TARGET",target:w,kind:"exact",domPathHash:x(t),page:this.pageContext},v=>{this.stop(),v!=null&&v.success?this.showToast(`🛡️ Domínio ${w} bloqueado no Pi-hole com sucesso!`):this.showToast(`⚠️ Não foi possível bloquear: ${(v==null?void 0:v.message)||"erro de conexão"}`)}):this.stop()})}onContextMenu(t){!this.active||this.modalOpen||(t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation(),this.stop(),this.showToast("Inspetor cancelado."))}onKeyDown(t){t.key==="Escape"&&(this.stop(),this.showToast("Inspetor cancelado."))}extractUrlsFromElement(t){const i=[],e=n=>{if(!n||typeof n!="string")return;const d=n.trim();if(d.startsWith("http://")||d.startsWith("https://"))i.push(d);else if(d.startsWith("//"))i.push(`https:${d}`);else if(d.includes("://")||d.includes(".")){const p=d.match(/(?:https?:)?\/\/[a-z0-9.-]+\.[a-z]{2,}(?::\d+)?(?:\/[^\s'"\)\]<>]*)?/gi);if(p)for(const c of p)i.push(c.startsWith("//")?`https:${c}`:c)}},o=n=>{e(n.getAttribute("src")),e(n.getAttribute("href")),e(n.getAttribute("data-src")),e(n.getAttribute("data-url")),e(n.getAttribute("data-target")),e(n.getAttribute("data-href")),e(n.getAttribute("data-link")),e(n.getAttribute("data-target-url")),e(n.getAttribute("data-popup")),e(n.getAttribute("data-click")),e(n.getAttribute("data-redirect")),e(n.getAttribute("data-ad-client")),e(n.getAttribute("data-video-url")),e(n.getAttribute("data-yaps-origin")),e(n.getAttribute("onclick")),e(n.getAttribute("onmousedown")),e(n.getAttribute("onpointerdown")),n instanceof HTMLIFrameElement&&n.src&&e(n.src),n instanceof HTMLVideoElement&&(e(n.currentSrc),e(n.src)),n instanceof HTMLAudioElement&&(e(n.currentSrc),e(n.src)),n instanceof HTMLSourceElement&&n.src&&e(n.src),n instanceof HTMLImageElement&&n.currentSrc&&e(n.currentSrc),n instanceof HTMLAnchorElement&&n.href&&e(n.href);try{const d=window.getComputedStyle(n).backgroundImage;if(d&&d!=="none"){const p=d.match(/url\(['"]?((?:https?:|\/\/)[^'"]+)['"]?\)/i);p!=null&&p[1]&&e(p[1])}}catch{}};o(t);const s=t.querySelectorAll("a, img, iframe, script, source, video, audio, embed, object, div[data-src], div[data-url], div[data-href]");for(const n of s)o(n);let l=t.parentElement,a=0;for(;l&&a<6;){o(l);const n=l.querySelector("iframe, video, source, a[href^='http'], a[href^='//'], a[href*='.']");n&&o(n),l=l.parentElement,a++}return Array.from(new Set(i))}showToast(t){const i=document.createElement("div");i.className="yapd-sentinel-toast",Object.assign(i.style,{position:"fixed",bottom:"20px",right:"20px",zIndex:"2147483647",padding:"10px 16px",backgroundColor:"#18181b",color:"#ffffff",fontSize:"13px",fontFamily:"system-ui, -apple-system, sans-serif",borderRadius:"8px",boxShadow:"0 4px 14px rgba(0,0,0,0.4)",border:"1px solid #3f3f46",transition:"opacity 0.3s ease",pointerEvents:"none"}),i.textContent=t,(document.body||document.documentElement).appendChild(i),setTimeout(()=>{i.style.opacity="0",setTimeout(()=>i.remove(),3e3)},3500)}}class T{constructor(t){h(this,"observer",null);h(this,"pageContext");h(this,"seenUrls",new Set);this.pageContext=t,this.handleWindowMessage=this.handleWindowMessage.bind(this)}start(){window.addEventListener("message",this.handleWindowMessage),this.observer=new MutationObserver(t=>{if(!this.isSensitivePage())for(const i of t)if(i.type==="childList")for(const e of i.addedNodes)e instanceof HTMLElement&&this.inspectNode(e);else i.type==="attributes"&&i.target instanceof HTMLElement&&this.inspectNode(i.target)}),document.documentElement?(this.observer.observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["src","data-src"]}),this.inspectInitialDom()):document.addEventListener("DOMContentLoaded",()=>{this.observer&&document.documentElement&&(this.observer.observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["src","data-src"]}),this.inspectInitialDom())})}stop(){var t;(t=this.observer)==null||t.disconnect(),this.observer=null,window.removeEventListener("message",this.handleWindowMessage)}isSensitivePage(){if(document.querySelector('input[type="password"]'))return!0;const t=window.location.href.toLowerCase();return t.includes("login")||t.includes("signin")||t.includes("auth")||t.includes("bank")||t.includes("checkout")}inspectInitialDom(){if(this.isSensitivePage())return;const t=document.querySelectorAll("script[src], iframe[src], ins.adsbygoogle, div.publicidade, div.patrocinado");for(const i of t)i instanceof HTMLElement&&this.inspectNode(i)}inspectNode(t){var p;if(this.isSensitivePage())return;const i=t.tagName.toLowerCase(),e=t.getAttribute("src")||t.getAttribute("data-src")||t.src,o=((p=t.dataset)==null?void 0:p.yapsOrigin)||t.getAttribute("data-yaps-origin"),s=`${t.className||""} ${t.id||""}`,l=x(t);let a=0,n=0;try{const c=t.getBoundingClientRect();a=Math.round(c.width),n=Math.round(c.height)}catch{}if(e&&typeof e=="string"&&!this.seenUrls.has(e)){this.seenUrls.add(e);const c=C(e,this.pageContext.domain,"main_world_dom_mutation",{elementTag:i,initiatorScript:o||void 0,classOrId:s,width:a,height:n,domPathHash:l,elementId:t.id||void 0,elementClasses:[...t.classList]});c&&this.sendCandidate(c)}const d=t.querySelectorAll("script[src], iframe[src]");for(const c of d)if(c instanceof HTMLElement){const f=c.getAttribute("src");if(f&&!this.seenUrls.has(f)){this.seenUrls.add(f);const m=C(f,this.pageContext.domain,"main_world_dom_mutation",{elementTag:c.tagName.toLowerCase(),initiatorScript:o||void 0,domPathHash:x(c)});m&&this.sendCandidate(m)}}}handleWindowMessage(t){if(this.isSensitivePage()||t.source!==window||!t.data||t.data.source!=="YAPS_MAIN_INJECTOR")return;const{url:i,resourceType:e,initiator:o}=t.data;if(i&&!this.seenUrls.has(i)){this.seenUrls.add(i);const s=C(i,this.pageContext.domain,"main_world_dom_mutation",{elementTag:e,initiatorScript:o});s&&this.sendCandidate(s)}}sendCandidate(t){!t||this.isSensitivePage()||typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage({type:"CANDIDATE_DETECTED",page:this.pageContext,candidate:t})}}(()=>{const r=window===window.top,t={url:window.location.href,domain:window.location.hostname,title:document.title};new T(t).start();const e=r?new I(t):null;if(r)try{document.documentElement.setAttribute("data-yapd-extension-installed","true"),window.postMessage({type:"YAPD_EXTENSION_PONG",version:"0.2.0"},"*"),window.addEventListener("message",o=>{var s;((s=o.data)==null?void 0:s.type)==="YAPD_EXTENSION_PING"&&(document.documentElement.setAttribute("data-yapd-extension-installed","true"),window.postMessage({type:"YAPD_EXTENSION_PONG",version:"0.2.0"},"*"))})}catch{}typeof chrome<"u"&&chrome.runtime&&r&&chrome.runtime.onMessage.addListener((o,s,l)=>o.type==="START_ELEMENT_PICKER"?(e==null||e.start(),l({status:"picker_started"}),!0):o.type==="STOP_ELEMENT_PICKER"?(e==null||e.stop(),l({status:"picker_stopped"}),!0):!1),console.debug("[YAPS] Isolated Content Script ativo em",t.domain,r?"(top)":"(frame)")})()})();
