var M = Object.defineProperty;
var L = (s, t, n) => t in s ? M(s, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : s[t] = n;
var T = (s, t, n) => L(s, typeof t != "symbol" ? t + "" : t, n);
const B = {
  sendPageTitle: !0,
  hardBlockedUrlPatterns: [],
  sensitiveUrlPatterns: ["*://*.bank*", "*://*.gov.br*", "*://login.*", "*://auth.*"],
  minScoreThreshold: 30,
  autoSendToYapd: !1
  // Por padrão, mantém na memória local da aba; envia sob demanda ou ao bloquear
}, y = {
  yapdBaseUrl: "http://localhost:3000",
  paired: !1,
  token: null,
  extensionId: null,
  deviceName: "YAPD Sentinel Browser",
  settings: B,
  activeInspectionEnabled: !0
}, Y = [
  /doubleclick\.net/i,
  /googlesyndication\.com/i,
  /googleadservices\.com/i,
  /criteo\.(com|net)/i,
  /taboola\.com/i,
  /outbrain\.com/i,
  /teads\.tv/i,
  /onetag-sys\.com/i,
  /2mdn\.net/i,
  /adnxs\.com/i,
  /rubiconproject\.com/i,
  /pubmatic\.com/i,
  /openx\.net/i,
  /casalemedia\.com/i,
  /smartadserver\.com/i,
  /adform\.net/i,
  /scorecardresearch\.com/i,
  /advertising\.com/i,
  /amazon-adsystem\.com/i,
  /adservice/i,
  /adsystem/i,
  /adserver/i,
  /tracking/i,
  /telemetry/i,
  /pixel/i,
  /beacon/i,
  /analytics/i,
  /sponsor/i
], O = [
  "adsbygoogle",
  "ad-slot",
  "ad-container",
  "advertisement",
  "banner-ad",
  "sponsor-slot",
  "taboola-container",
  "outbrain-widget",
  "dfp-ad",
  "publicidade",
  "patrocinado",
  "anuncio",
  "propaganda",
  "adserver",
  "banner",
  "ad-wrapper",
  "ad-unit",
  "native-ad"
], N = [
  { width: 300, height: 250 },
  // Medium Rectangle
  { width: 728, height: 90 },
  // Leaderboard
  { width: 160, height: 600 },
  // Wide Skyscraper
  { width: 300, height: 600 },
  // Half Page
  { width: 970, height: 250 },
  // Billboard
  { width: 320, height: 50 },
  // Mobile Leaderboard
  { width: 320, height: 100 }
  // Large Mobile
], R = 3e3, q = 50, U = /* @__PURE__ */ new Set([
  "com.br",
  "net.br",
  "org.br",
  "gov.br",
  "edu.br",
  "co.uk",
  "org.uk",
  "me.uk",
  "com.au",
  "net.au",
  "co.nz",
  "co.jp"
]);
function g(s) {
  if (!s || typeof s != "string")
    return null;
  const t = s.trim();
  if (!t || t.startsWith("javascript:") || t.startsWith("about:") || t.startsWith("data:") || !t.includes("://") && !t.includes(".") && !t.startsWith("localhost"))
    return null;
  try {
    let n = t;
    n.startsWith("//") ? n = `https:${n}` : n.includes("://") || (n = `https://${n}`);
    const e = new URL(n);
    return !e.hostname || !e.hostname.includes(".") && e.hostname !== "localhost" ? null : e.hostname.toLowerCase();
  } catch {
    return null;
  }
}
function l(s) {
  const t = s.toLowerCase().split(".");
  if (t.length <= 2)
    return s.toLowerCase();
  const n = `${t[t.length - 2]}.${t[t.length - 1]}`;
  return U.has(n) && t.length >= 3 ? `${t[t.length - 3]}.${n}` : `${t[t.length - 2]}.${t[t.length - 1]}`;
}
function z(s, t) {
  const n = l(s), e = l(t);
  return n !== e;
}
function k(s) {
  return Y.some((t) => t.test(s));
}
function I(s, t) {
  return N.some(
    (n) => Math.abs(n.width - s) <= 5 && Math.abs(n.height - t) <= 5
  );
}
function F(s) {
  const t = s.toLowerCase();
  return O.some((n) => t.includes(n));
}
function P(s, t) {
  if (!t || t.length === 0) return !1;
  const n = s.toLowerCase();
  return t.some((e) => {
    try {
      return new RegExp(`^${e.replace(/\./g, "\\.").replace(/\*/g, ".*")}$`, "i").test(n);
    } catch {
      return !1;
    }
  });
}
function W(s, t, n, e) {
  const o = g(s);
  if (!o)
    return null;
  const i = l(o), r = z(o, t);
  if (!r && n !== "user_inspector_click")
    return null;
  const a = [];
  let c = 10, d = r ? "third_party" : "site_asset";
  r && (a.push("Third-party resource outside main page domain"), c += 20), (k(s) || k(o)) && (a.push("Matches known ad-network or tracking pattern"), c += 45, d = "ads"), e != null && e.initiatorScript && (a.push(`Injected by script: ${e.initiatorScript}`), c += 15), e != null && e.classOrId && F(e.classOrId) && (a.push(`Container attributes indicate advertisement (${e.classOrId})`), c += 25, d = "ads"), e != null && e.width && (e != null && e.height) && I(e.width, e.height) && (a.push(
    `Element dimensions match standard IAB ad banner (${e.width}x${e.height})`
  ), c += 20, d = "ads"), c = Math.min(100, c);
  let m = "low";
  return c >= 70 ? m = "high" : c >= 30 && (m = "medium"), {
    candidateId: `cand-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    target: i,
    category: d,
    score: c,
    riskLevel: m,
    reasons: a,
    evidence: {
      url: s,
      source: n,
      resourceType: (e == null ? void 0 : e.elementTag) || "unknown",
      isThirdParty: r,
      elementTag: e == null ? void 0 : e.elementTag,
      initiatorScript: e == null ? void 0 : e.initiatorScript,
      domPathHash: e == null ? void 0 : e.domPathHash,
      elementId: e == null ? void 0 : e.elementId,
      elementClasses: e == null ? void 0 : e.elementClasses,
      dimensions: e != null && e.width && (e != null && e.height) ? { width: e.width, height: e.height } : void 0,
      timestamp: Date.now()
    }
  };
}
const w = "yaps_extension_state";
class j {
  constructor() {
    T(this, "inMemoryFallback", { ...y });
  }
  async getState() {
    var t;
    if (typeof chrome < "u" && ((t = chrome.storage) != null && t.local)) {
      const n = await chrome.storage.local.get(w);
      if (n != null && n[w])
        return {
          ...y,
          ...n[w],
          settings: {
            ...y.settings,
            ...n[w].settings
          }
        };
    }
    return this.inMemoryFallback;
  }
  async setState(t) {
    var o;
    const n = await this.getState(), e = {
      ...n,
      ...t,
      settings: {
        ...n.settings,
        ...t.settings || {}
      }
    };
    return typeof chrome < "u" && ((o = chrome.storage) != null && o.local) ? await chrome.storage.local.set({ [w]: e }) : this.inMemoryFallback = e, e;
  }
  async setPaired(t, n, e) {
    await this.setState({
      paired: !0,
      token: t,
      extensionId: n,
      settings: e || y.settings
    });
  }
  async disconnect() {
    await this.setState({
      paired: !1,
      token: null,
      extensionId: null
    });
  }
}
const u = new j();
class H {
  getApiEndpoint(t, n) {
    const e = t.trim().replace(/\/+$/, ""), o = e.endsWith("/api") ? e : `${e}/api`, i = n.replace(/^\/+/, "");
    return `${o}/${i}`;
  }
  async pair(t, n, e = "YAPD Sentinel Browser") {
    const o = this.getApiEndpoint(t, "browser-extension/pair"), i = await fetch(o, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        pairingCode: n.trim(),
        extensionName: e,
        browser: "Chrome",
        manifestVersion: 3,
        extensionVersion: "0.2.0"
      })
    });
    if (!i.ok) {
      const c = await i.text();
      throw new Error(`Falha no pareamento com YAPD (${i.status}): ${c}`);
    }
    const r = await i.json(), a = t.trim().replace(/\/+$/, "").replace(/\/api$/, "");
    return await u.setState({ yapdBaseUrl: a }), await u.setPaired(r.accessToken, r.extensionId, r.settings), r;
  }
  async sendReport(t) {
    const n = await u.getState();
    if (!n.paired || !n.token)
      return console.warn("[YAPD Sentinel] Extensão não está pareada. Relatório ignorado."), null;
    const e = this.getApiEndpoint(n.yapdBaseUrl, "browser-extension/detections/report"), o = await fetch(e, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${n.token}`
      },
      body: JSON.stringify(t)
    });
    if (!o.ok) {
      const i = await o.text();
      return console.error(`[YAPD Sentinel] Falha ao enviar relatório (${o.status}): ${i}`), (o.status === 401 || o.status === 403) && await u.disconnect(), null;
    }
    return await o.json();
  }
  async applyBlockTarget(t, n, e, o = "exact") {
    const i = await u.getState();
    if (!i.paired || !i.token || !i.extensionId)
      return { success: !1, message: "Extensão não conectada ao YAPD." };
    const r = this.getApiEndpoint(i.yapdBaseUrl, "browser-extension/detections/apply"), a = t.toLowerCase().trim(), c = {
      source: "browser_extension",
      extension: {
        name: i.deviceName,
        extensionId: i.extensionId,
        version: "0.2.0",
        browser: "Chrome",
        manifestVersion: 3
      },
      clientRequestId: `req-block-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      page: {
        url: n.url,
        domain: n.domain,
        title: i.settings.sendPageTitle ? n.title : void 0
      },
      action: "apply_user_approved_detections",
      approvedTargets: [
        {
          candidateId: (e == null ? void 0 : e.candidateId) || `cand-manual-${Date.now()}`,
          target: a,
          type: "deny",
          kind: o,
          category: (e == null ? void 0 : e.category) || "ads",
          score: (e == null ? void 0 : e.score) || 95,
          riskLevel: (e == null ? void 0 : e.riskLevel) || "high",
          reasons: (e == null ? void 0 : e.reasons) || ["Bloqueado diretamente pelo usuário no YAPD Sentinel"],
          evidence: {
            url: (e == null ? void 0 : e.evidence.url) || n.url,
            source: (e == null ? void 0 : e.evidence.source) || "user_inspector_click",
            isThirdParty: !0,
            resourceType: (e == null ? void 0 : e.evidence.resourceType) || "script"
          }
        }
      ]
    };
    try {
      const d = await fetch(r, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${i.token}`
        },
        body: JSON.stringify(c)
      });
      if (!d.ok) {
        const m = await d.text();
        return { success: !1, message: `Erro ao aplicar bloqueio (${d.status}): ${m}` };
      }
      return { success: !0 };
    } catch (d) {
      return { success: !1, message: d.message };
    }
  }
  async fetchConfig() {
    const t = await u.getState();
    if (!t.paired || !t.token)
      return null;
    const n = this.getApiEndpoint(t.yapdBaseUrl, "browser-extension/config");
    try {
      const e = await fetch(n, {
        headers: {
          Authorization: `Bearer ${t.token}`
        }
      });
      if (!e.ok)
        return (e.status === 401 || e.status === 403) && (console.warn(
          "[YAPD Sentinel] Token de pareamento rejeitado pelo YAPD (banco resetado ou dispositivo revogado). Desconectando."
        ), await u.disconnect()), null;
      const o = await e.json();
      return o.settings && await u.setState({ settings: { ...t.settings, ...o.settings } }), o;
    } catch (e) {
      return console.warn("[YAPD Sentinel] Erro ao sincronizar configurações do YAPD:", e), null;
    }
  }
}
const S = new H();
class K {
  constructor() {
    T(this, "sessions", /* @__PURE__ */ new Map());
    T(this, "domainFallbackMap", /* @__PURE__ */ new Map());
    T(this, "blockedTargets", /* @__PURE__ */ new Set());
    var t;
    typeof chrome < "u" && ((t = chrome.tabs) != null && t.onRemoved) && chrome.tabs.onRemoved.addListener((n) => {
      this.clearSession(n);
    });
  }
  clearSession(t) {
    const n = this.sessions.get(t);
    n != null && n.debounceTimer && clearTimeout(n.debounceTimer), this.sessions.delete(t);
  }
  enqueue(t, n, e, o = !1) {
    if (!e || e <= 0)
      return;
    let i = this.sessions.get(e);
    if (!i)
      i = {
        tabId: e,
        page: t,
        targets: /* @__PURE__ */ new Map(),
        savedToYapd: !1,
        debounceTimer: null
      }, this.sessions.set(e, i);
    else {
      const c = l(i.page.domain), d = l(t.domain);
      c !== d ? (i.debounceTimer && clearTimeout(i.debounceTimer), i.page = t, i.targets.clear(), i.savedToYapd = !1, i.debounceTimer = null) : t.title && !i.page.title && (i.page.title = t.title);
    }
    const r = i.targets.get(n.target);
    if (r && r.score >= n.score)
      return;
    (this.blockedTargets.has(n.target.toLowerCase()) || this.blockedTargets.has(l(n.target))) && (n.isBlocked = !0), i.targets.set(n.target, n), this.domainFallbackMap.set(l(i.page.domain), i);
    const a = i.targets.size;
    typeof chrome < "u" && chrome.action && (chrome.action.setBadgeText({
      tabId: e,
      text: String(a)
    }), chrome.action.setBadgeBackgroundColor({
      tabId: e,
      color: "#dc2626"
    })), u.getState().then((c) => {
      if (c.settings.autoSendToYapd || o) {
        if (o || i.targets.size >= q) {
          this.flushSession(e);
          return;
        }
        i.debounceTimer && clearTimeout(i.debounceTimer), i.debounceTimer = setTimeout(() => {
          this.flushSession(e);
        }, R);
      }
    });
  }
  async flushSession(t) {
    const n = this.sessions.get(t);
    if (!n || n.targets.size === 0)
      return { success: !1 };
    n.debounceTimer && (clearTimeout(n.debounceTimer), n.debounceTimer = null);
    const e = await u.getState();
    if (!e.paired || !e.extensionId)
      return { success: !1 };
    const o = {
      name: e.deviceName,
      extensionId: e.extensionId,
      version: "0.2.0",
      browser: "Chrome",
      manifestVersion: 3
    }, i = Array.from(n.targets.values()), r = {
      source: "browser_extension",
      extension: o,
      clientRequestId: `req-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      page: {
        url: n.page.url,
        domain: n.page.domain,
        title: e.settings.sendPageTitle ? n.page.title : void 0
      },
      action: "report_detected_items",
      detectedTargets: i
    };
    try {
      const a = await S.sendReport(r);
      return a != null && a.batchId ? (n.savedToYapd = !0, { success: !0, batchId: a.batchId }) : { success: !1 };
    } catch (a) {
      return console.error("[YAPD Sentinel] Erro ao despachar análise para o YAPD:", a), { success: !1 };
    }
  }
  markTargetAsBlocked(t, n) {
    const e = t.toLowerCase().trim(), o = l(e);
    this.blockedTargets.add(e), o && this.blockedTargets.add(o);
    for (const i of this.sessions.values())
      for (const [, r] of i.targets.entries()) {
        const a = r.target.toLowerCase(), c = l(a);
        (a === e || a === o || c === e || c === o) && (r.isBlocked = !0);
      }
  }
  getPageSummary(t, n) {
    const e = (o) => o.map((i) => ({
      ...i,
      isBlocked: i.isBlocked || this.blockedTargets.has(i.target.toLowerCase()) || this.blockedTargets.has(l(i.target))
    })).sort((i, r) => r.score - i.score);
    if (n && this.sessions.has(n)) {
      const o = this.sessions.get(n);
      return {
        count: o.targets.size,
        targets: e(Array.from(o.targets.values())),
        savedToYapd: o.savedToYapd
      };
    }
    if (t) {
      const o = l(t.toLowerCase()), i = this.domainFallbackMap.get(o);
      if (i)
        return {
          count: i.targets.size,
          targets: e(Array.from(i.targets.values())),
          savedToYapd: i.savedToYapd
        };
    }
    return { count: 0, targets: [], savedToYapd: !1 };
  }
}
const f = new K();
function G() {
  var s;
  typeof chrome > "u" || !((s = chrome.webRequest) != null && s.onBeforeRequest) || chrome.webRequest.onBeforeRequest.addListener(
    (t) => {
      t.tabId <= 0 || t.url.startsWith("chrome-extension://") || u.getState().then((n) => {
        !n.activeInspectionEnabled || !n.paired || chrome.tabs.get(t.tabId, (e) => {
          if (chrome.runtime.lastError || !e || !e.url || P(e.url, n.settings.sensitiveUrlPatterns) || P(e.url, n.settings.hardBlockedUrlPatterns))
            return;
          const o = g(e.url);
          if (!o)
            return;
          const i = W(t.url, o, "web_request", {
            elementTag: t.type,
            initiatorScript: t.initiator
          });
          i && f.enqueue(
            {
              url: e.url,
              domain: o,
              title: e.title
            },
            i,
            t.tabId
          );
        });
      });
    },
    { urls: ["<all_urls>"] }
  );
}
console.log("[YAPD Sentinel] Service Worker iniciado.");
G();
function V(s, t, n) {
  var o;
  const e = s.tab;
  if (e != null && e.url) {
    const i = g(e.url);
    if (i) {
      n({
        url: e.url,
        domain: i,
        title: e.title || (t == null ? void 0 : t.title)
      });
      return;
    }
  }
  if (e != null && e.id && typeof chrome < "u" && ((o = chrome.tabs) != null && o.get)) {
    chrome.tabs.get(e.id, (i) => {
      if (!chrome.runtime.lastError && (i != null && i.url)) {
        const r = g(i.url);
        if (r) {
          n({
            url: i.url,
            domain: r,
            title: i.title || (t == null ? void 0 : t.title)
          });
          return;
        }
      }
      n(t);
    });
    return;
  }
  n(t);
}
typeof chrome < "u" && chrome.runtime && (chrome.runtime.onInstalled.addListener(() => {
  console.log("[YAPD Sentinel] Extensão instalada/atualizada."), chrome.alarms.create("yapd_sentinel_sync_config", { periodInMinutes: 30 }), S.fetchConfig().catch(console.error);
}), chrome.alarms.onAlarm.addListener((s) => {
  s.name === "yapd_sentinel_sync_config" && S.fetchConfig().catch(console.error);
}), chrome.runtime.onMessage.addListener((s, t, n) => {
  var o, i;
  const e = (o = t.tab) == null ? void 0 : o.id;
  if (s.type === "CANDIDATE_DETECTED" || s.type === "PICKER_DETECTED") {
    const r = s.type === "PICKER_DETECTED";
    return u.getState().then((a) => {
      a.paired && (!r && !a.activeInspectionEnabled || V(t, s.page, (c) => {
        var d;
        t.frameId && t.frameId !== 0 && (s.candidate.evidence = {
          ...s.candidate.evidence,
          frameUrl: t.url || ((d = s.page) == null ? void 0 : d.url)
        }), f.enqueue(c, s.candidate, e, r);
      }));
    }), n({ status: r ? "queued_immediate" : "queued" }), !0;
  }
  if (s.type === "GET_PAGE_SUMMARY") {
    const r = s.tabId || e, a = s.pageDomain || ((i = t.tab) != null && i.url ? g(t.tab.url) ?? void 0 : void 0), c = f.getPageSummary(a, r);
    return n(c), !0;
  }
  if (s.type === "SAVE_PAGE_ANALYSIS_TO_YAPD") {
    const r = s.tabId || e;
    return r ? (f.flushSession(r).then((a) => {
      n(a);
    }), !0) : (n({ success: !1, message: "Aba não identificada." }), !0);
  }
  if (s.type === "QUICK_BLOCK_TARGET") {
    const r = s.tabId || e;
    return u.getState().then(async (a) => {
      var b, v, _, E, D, C;
      if (!a.paired) {
        n({ success: !1, message: "Extensão desconectada." });
        return;
      }
      const d = f.getPageSummary(void 0, r).targets.find(
        (p) => p.target.toLowerCase() === s.target.toLowerCase()
      );
      let m = (b = s.page) == null ? void 0 : b.url, h = (v = s.page) == null ? void 0 : v.domain;
      if (!h || h === "unknown") {
        let p = t.tab;
        if (!p && r && typeof chrome < "u" && ((_ = chrome.tabs) != null && _.get))
          try {
            p = await chrome.tabs.get(r);
          } catch {
          }
        if (!p && typeof chrome < "u" && ((E = chrome.tabs) != null && E.query))
          try {
            p = (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
          } catch {
          }
        p != null && p.url && (m = p.url, h = g(p.url) || void 0);
      }
      (!h || h === "unknown" || !h.includes(".")) && (h = l(s.target) || "sentinel.local", m = m || `https://${h}`);
      const $ = {
        url: m || `https://${h}`,
        domain: h,
        title: ((D = s.page) == null ? void 0 : D.title) || ((C = t.tab) == null ? void 0 : C.title)
      }, A = await S.applyBlockTarget(
        s.target,
        $,
        d,
        s.kind || "exact"
      );
      A.success && f.markTargetAsBlocked(s.target, r), n(A);
    }), !0;
  }
  return !1;
}));
