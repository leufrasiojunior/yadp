var Y = Object.defineProperty;
var B = (o, t, n) => t in o ? Y(o, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : o[t] = n;
var S = (o, t, n) => B(o, typeof t != "symbol" ? t + "" : t, n);
const _ = "0.2.1";
const N = {
  sendPageTitle: !0,
  hardBlockedUrlPatterns: [],
  sensitiveUrlPatterns: ["*://*.bank*", "*://*.gov.br*", "*://login.*", "*://auth.*"],
  minScoreThreshold: 30,
  autoSendToYapd: !1
  // Por padrão, mantém na memória local da aba; envia sob demanda ou ao bloquear
}, b = {
  yapdBaseUrl: "http://localhost:3000",
  paired: !1,
  token: null,
  extensionId: null,
  deviceName: "YAPD Sentinel Browser",
  settings: N,
  activeInspectionEnabled: !0
}, O = [
  /doubleclick\.net/i,
  /googlesyndication\.com/i,
  /googleadservices\.com/i,
  /criteo\.(com|net)/i,
  /taboola\.com/i,
  /outbrain\.com/i,
  /teads\.tv/i,
  /onetag-sys\.com/i,
  /2mdn\.net/i,
  /adnxs\.com/i,
  /rubiconproject\.com/i,
  /pubmatic\.com/i,
  /openx\.net/i,
  /casalemedia\.com/i,
  /smartadserver\.com/i,
  /adform\.net/i,
  /scorecardresearch\.com/i,
  /advertising\.com/i,
  /amazon-adsystem\.com/i,
  /adservice/i,
  /adsystem/i,
  /adserver/i,
  /tracking/i,
  /telemetry/i,
  /pixel/i,
  /beacon/i,
  /analytics/i,
  /sponsor/i
], R = [
  "adsbygoogle",
  "ad-slot",
  "ad-container",
  "advertisement",
  "banner-ad",
  "sponsor-slot",
  "taboola-container",
  "outbrain-widget",
  "dfp-ad",
  "publicidade",
  "patrocinado",
  "anuncio",
  "propaganda",
  "adserver",
  "banner",
  "ad-wrapper",
  "ad-unit",
  "native-ad"
], q = [
  { width: 300, height: 250 },
  // Medium Rectangle
  { width: 728, height: 90 },
  // Leaderboard
  { width: 160, height: 600 },
  // Wide Skyscraper
  { width: 300, height: 600 },
  // Half Page
  { width: 970, height: 250 },
  // Billboard
  { width: 320, height: 50 },
  // Mobile Leaderboard
  { width: 320, height: 100 }
  // Large Mobile
], I = 3e3, U = 50, F = /* @__PURE__ */ new Set([
  "com.br",
  "net.br",
  "org.br",
  "gov.br",
  "edu.br",
  "co.uk",
  "org.uk",
  "me.uk",
  "com.au",
  "net.au",
  "co.nz",
  "co.jp"
]);
function g(o) {
  if (!o || typeof o != "string")
    return null;
  const t = o.trim();
  if (!t || t.startsWith("javascript:") || t.startsWith("about:") || t.startsWith("data:") || !t.includes("://") && !t.includes(".") && !t.startsWith("localhost"))
    return null;
  try {
    let n = t;
    n.startsWith("//") ? n = `https:${n}` : n.includes("://") || (n = `https://${n}`);
    const e = new URL(n);
    return !e.hostname || !e.hostname.includes(".") && e.hostname !== "localhost" ? null : e.hostname.toLowerCase();
  } catch {
    return null;
  }
}
function u(o) {
  const t = o.toLowerCase().split(".");
  if (t.length <= 2)
    return o.toLowerCase();
  const n = `${t[t.length - 2]}.${t[t.length - 1]}`;
  return F.has(n) && t.length >= 3 ? `${t[t.length - 3]}.${n}` : `${t[t.length - 2]}.${t[t.length - 1]}`;
}
function z(o, t) {
  const n = u(o), e = u(t);
  return n !== e;
}
function M(o) {
  return O.some((t) => t.test(o));
}
function j(o, t) {
  return q.some(
    (n) => Math.abs(n.width - o) <= 5 && Math.abs(n.height - t) <= 5
  );
}
function W(o) {
  const t = o.toLowerCase();
  return R.some((n) => t.includes(n));
}
function L(o, t) {
  if (!t || t.length === 0) return !1;
  const n = o.toLowerCase();
  return t.some((e) => {
    try {
      return new RegExp(`^${e.replace(/\./g, "\\.").replace(/\*/g, ".*")}$`, "i").test(n);
    } catch {
      return !1;
    }
  });
}
function H(o, t, n, e) {
  const i = g(o);
  if (!i)
    return null;
  const s = u(i), r = z(i, t);
  if (!r && n !== "user_inspector_click")
    return null;
  const d = [];
  let c = 10, l = r ? "third_party" : "site_asset";
  r && (d.push("Third-party resource outside main page domain"), c += 20), (M(o) || M(i)) && (d.push("Matches known ad-network or tracking pattern"), c += 45, l = "ads"), e != null && e.initiatorScript && (d.push(`Injected by script: ${e.initiatorScript}`), c += 15), e != null && e.classOrId && W(e.classOrId) && (d.push(`Container attributes indicate advertisement (${e.classOrId})`), c += 25, l = "ads"), e != null && e.width && (e != null && e.height) && j(e.width, e.height) && (d.push(
    `Element dimensions match standard IAB ad banner (${e.width}x${e.height})`
  ), c += 20, l = "ads"), c = Math.min(100, c);
  let p = "low";
  return c >= 70 ? p = "high" : c >= 30 && (p = "medium"), {
    candidateId: `cand-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    target: s,
    category: l,
    score: c,
    riskLevel: p,
    reasons: d,
    evidence: {
      url: o,
      source: n,
      resourceType: (e == null ? void 0 : e.elementTag) || "unknown",
      isThirdParty: r,
      elementTag: e == null ? void 0 : e.elementTag,
      initiatorScript: e == null ? void 0 : e.initiatorScript,
      domPathHash: e == null ? void 0 : e.domPathHash,
      elementId: e == null ? void 0 : e.elementId,
      elementClasses: e == null ? void 0 : e.elementClasses,
      dimensions: e != null && e.width && (e != null && e.height) ? { width: e.width, height: e.height } : void 0,
      timestamp: Date.now()
    }
  };
}
const v = "yaps_extension_state";
class K {
  constructor() {
    S(this, "inMemoryFallback", { ...b });
  }
  async getState() {
    var t;
    if (typeof chrome < "u" && ((t = chrome.storage) != null && t.local)) {
      const n = await chrome.storage.local.get(v);
      if (n != null && n[v])
        return {
          ...b,
          ...n[v],
          settings: {
            ...b.settings,
            ...n[v].settings
          }
        };
    }
    return this.inMemoryFallback;
  }
  async setState(t) {
    var i;
    const n = await this.getState(), e = {
      ...n,
      ...t,
      settings: {
        ...n.settings,
        ...t.settings || {}
      }
    };
    return typeof chrome < "u" && ((i = chrome.storage) != null && i.local) ? await chrome.storage.local.set({ [v]: e }) : this.inMemoryFallback = e, e;
  }
  async setPaired(t, n, e) {
    await this.setState({
      paired: !0,
      token: t,
      extensionId: n,
      settings: e || b.settings
    });
  }
  async disconnect() {
    await this.setState({
      paired: !1,
      token: null,
      extensionId: null
    });
  }
}
const h = new K();
class G {
  getApiEndpoint(t, n) {
    const e = t.trim().replace(/\/+$/, ""), i = e.endsWith("/api") ? e : `${e}/api`, s = n.replace(/^\/+/, "");
    return `${i}/${s}`;
  }
  async pair(t, n, e = "YAPD Sentinel Browser") {
    const i = this.getApiEndpoint(t, "browser-extension/pair"), s = await fetch(i, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        pairingCode: n.trim(),
        extensionName: e,
        browser: "Chrome",
        manifestVersion: 3,
        extensionVersion: _
      })
    });
    if (!s.ok) {
      const c = await s.text();
      throw new Error(`Falha no pareamento com YAPD (${s.status}): ${c}`);
    }
    const r = await s.json(), d = t.trim().replace(/\/+$/, "").replace(/\/api$/, "");
    return await h.setState({ yapdBaseUrl: d }), await h.setPaired(r.accessToken, r.extensionId, r.settings), r;
  }
  async sendReport(t) {
    const n = await h.getState();
    if (!n.paired || !n.token)
      return console.warn("[YAPD Sentinel] Extensão não está pareada. Relatório ignorado."), { success: !1, message: "Extensão desconectada do YAPD." };
    const e = this.getApiEndpoint(n.yapdBaseUrl, "browser-extension/detections/report");
    try {
      const i = await fetch(e, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${n.token}`
        },
        body: JSON.stringify(t)
      });
      if (!i.ok) {
        const r = await i.text();
        if (console.error(
          `[YAPD Sentinel] Falha ao enviar relatório (${i.status}): ${r}`
        ), i.status === 401 || i.status === 403)
          return await h.disconnect(), { success: !1, message: "Sessão expirada ou token revogado no YAPD." };
        let d = r;
        try {
          const c = JSON.parse(r);
          Array.isArray(c.message) ? d = c.message.join("; ") : c.message && (d = c.message);
        } catch {
        }
        return {
          success: !1,
          message: `Falha ao salvar (${i.status}): ${d}`
        };
      }
      return { success: !0, batchId: (await i.json()).batchId };
    } catch (i) {
      const s = i.message || "Erro de conexão";
      return console.error("[YAPD Sentinel] Erro ao comunicar com YAPD:", i), { success: !1, message: `Erro de rede ao conectar no YAPD: ${s}` };
    }
  }
  async applyBlockTarget(t, n, e, i = "exact") {
    const s = await h.getState();
    if (!s.paired || !s.token || !s.extensionId)
      return { success: !1, message: "Extensão não conectada ao YAPD." };
    const r = this.getApiEndpoint(s.yapdBaseUrl, "browser-extension/detections/apply"), d = t.toLowerCase().trim(), c = {
      source: "browser_extension",
      extension: {
        name: s.deviceName,
        extensionId: s.extensionId,
        version: _,
        browser: "Chrome",
        manifestVersion: 3
      },
      clientRequestId: `req-block-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      page: {
        url: n.url,
        domain: n.domain,
        title: s.settings.sendPageTitle ? n.title : void 0
      },
      action: "apply_user_approved_detections",
      approvedTargets: [
        {
          candidateId: (e == null ? void 0 : e.candidateId) || `cand-manual-${Date.now()}`,
          target: d,
          type: "deny",
          kind: i,
          category: (e == null ? void 0 : e.category) || "ads",
          score: (e == null ? void 0 : e.score) || 95,
          riskLevel: (e == null ? void 0 : e.riskLevel) || "high",
          reasons: (e == null ? void 0 : e.reasons) || ["Bloqueado diretamente pelo usuário no YAPD Sentinel"],
          evidence: {
            url: (e == null ? void 0 : e.evidence.url) || n.url,
            source: (e == null ? void 0 : e.evidence.source) || "user_inspector_click",
            isThirdParty: !0,
            resourceType: (e == null ? void 0 : e.evidence.resourceType) || "script"
          }
        }
      ]
    };
    try {
      const l = await fetch(r, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${s.token}`
        },
        body: JSON.stringify(c)
      });
      if (!l.ok) {
        const p = await l.text();
        return {
          success: !1,
          message: `Erro ao aplicar bloqueio (${l.status}): ${p}`
        };
      }
      return { success: !0 };
    } catch (l) {
      return { success: !1, message: l.message };
    }
  }
  async fetchConfig() {
    const t = await h.getState();
    if (!t.paired || !t.token)
      return null;
    const n = this.getApiEndpoint(t.yapdBaseUrl, "browser-extension/config");
    try {
      const e = await fetch(n, {
        headers: {
          Authorization: `Bearer ${t.token}`
        }
      });
      if (!e.ok)
        return (e.status === 401 || e.status === 403) && (console.warn(
          "[YAPD Sentinel] Token de pareamento rejeitado pelo YAPD (banco resetado ou dispositivo revogado). Desconectando."
        ), await h.disconnect()), null;
      const i = await e.json();
      return i.settings && await h.setState({ settings: { ...t.settings, ...i.settings } }), i;
    } catch (e) {
      return console.warn("[YAPD Sentinel] Erro ao sincronizar configurações do YAPD:", e), null;
    }
  }
}
const E = new G();
class V {
  constructor() {
    S(this, "sessions", /* @__PURE__ */ new Map());
    S(this, "domainFallbackMap", /* @__PURE__ */ new Map());
    S(this, "blockedTargets", /* @__PURE__ */ new Set());
    var t;
    typeof chrome < "u" && ((t = chrome.tabs) != null && t.onRemoved) && chrome.tabs.onRemoved.addListener((n) => {
      this.clearSession(n);
    });
  }
  clearSession(t) {
    const n = this.sessions.get(t);
    n != null && n.debounceTimer && clearTimeout(n.debounceTimer), this.sessions.delete(t);
  }
  enqueue(t, n, e, i = !1) {
    if (!e || e <= 0)
      return;
    let s = this.sessions.get(e);
    if (!s)
      s = {
        tabId: e,
        page: t,
        targets: /* @__PURE__ */ new Map(),
        savedToYapd: !1,
        debounceTimer: null
      }, this.sessions.set(e, s);
    else {
      const c = u(s.page.domain), l = u(t.domain);
      c !== l ? (s.debounceTimer && clearTimeout(s.debounceTimer), s.page = t, s.targets.clear(), s.savedToYapd = !1, s.debounceTimer = null) : t.title && !s.page.title && (s.page.title = t.title);
    }
    const r = s.targets.get(n.target);
    if (r && r.score >= n.score)
      return;
    (this.blockedTargets.has(n.target.toLowerCase()) || this.blockedTargets.has(u(n.target))) && (n.isBlocked = !0), s.targets.set(n.target, n), this.domainFallbackMap.set(u(s.page.domain), s);
    const d = s.targets.size;
    typeof chrome < "u" && chrome.action && (chrome.action.setBadgeText({
      tabId: e,
      text: String(d)
    }), chrome.action.setBadgeBackgroundColor({
      tabId: e,
      color: "#dc2626"
    })), h.getState().then((c) => {
      if (c.settings.autoSendToYapd || i) {
        if (i || s.targets.size >= U) {
          this.flushSession(e);
          return;
        }
        s.debounceTimer && clearTimeout(s.debounceTimer), s.debounceTimer = setTimeout(() => {
          this.flushSession(e);
        }, I);
      }
    });
  }
  async flushSession(t, n) {
    let e;
    if (t && this.sessions.has(t))
      e = this.sessions.get(t);
    else if (n) {
      const a = u(n.toLowerCase());
      e = this.domainFallbackMap.get(a);
    }
    if (!e || e.targets.size === 0)
      return { success: !1, message: "Não há dados ou rastreadores pendentes nesta página." };
    e.debounceTimer && (clearTimeout(e.debounceTimer), e.debounceTimer = null);
    const i = await h.getState();
    if (!i.paired || !i.extensionId)
      return { success: !1, message: "A extensão não está conectada ao YAPD." };
    const s = {
      name: i.deviceName,
      extensionId: i.extensionId,
      version: _,
      browser: "Chrome",
      manifestVersion: 3
    }, d = Array.from(e.targets.values()).map((a) => {
      var A, T, y, w;
      return {
        candidateId: a.candidateId,
        target: a.target.trim().toLowerCase(),
        category: a.category || "ads",
        score: Math.max(0, Math.min(100, Math.round(a.score))),
        riskLevel: a.riskLevel || (a.score >= 70 ? "high" : a.score >= 30 ? "medium" : "low"),
        reasons: a.reasons && a.reasons.length > 0 ? a.reasons : ["Rastreador detectado"],
        evidence: {
          url: (A = a.evidence) != null && A.url ? a.evidence.url.slice(0, 2048) : void 0,
          source: (((T = a.evidence) == null ? void 0 : T.source) || "web_request").slice(0, 100),
          resourceType: (((y = a.evidence) == null ? void 0 : y.resourceType) || "unknown").slice(0, 100),
          isThirdParty: !!((w = a.evidence) != null && w.isThirdParty)
        }
      };
    }), c = e.page.domain.trim().toLowerCase().slice(0, 253), l = e.page.url.slice(0, 2048), p = {
      source: "browser_extension",
      extension: s,
      clientRequestId: `req-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      page: {
        url: l,
        domain: c,
        title: i.settings.sendPageTitle && e.page.title ? e.page.title.slice(0, 300) : void 0
      },
      action: "report_detected_items",
      detectedTargets: d
    };
    try {
      const a = await E.sendReport(p);
      return a.success && a.batchId ? (e.savedToYapd = !0, { success: !0, batchId: a.batchId }) : { success: !1, message: a.message || "Falha ao salvar no YAPD." };
    } catch (a) {
      return console.error("[YAPD Sentinel] Erro ao despachar análise para o YAPD:", a), { success: !1, message: a.message };
    }
  }
  markTargetAsBlocked(t, n) {
    const e = t.toLowerCase().trim(), i = u(e);
    this.blockedTargets.add(e), i && this.blockedTargets.add(i);
    for (const s of this.sessions.values())
      for (const [, r] of s.targets.entries()) {
        const d = r.target.toLowerCase(), c = u(d);
        (d === e || d === i || c === e || c === i) && (r.isBlocked = !0);
      }
  }
  getPageSummary(t, n) {
    const e = (s) => s.map((r) => ({
      ...r,
      isBlocked: r.isBlocked || this.blockedTargets.has(r.target.toLowerCase()) || this.blockedTargets.has(u(r.target))
    })).sort((r, d) => d.score - r.score), i = n ? this.sessions.get(n) : void 0;
    if (i)
      return {
        count: i.targets.size,
        targets: e(Array.from(i.targets.values())),
        savedToYapd: i.savedToYapd
      };
    if (t) {
      const s = u(t.toLowerCase()), r = this.domainFallbackMap.get(s);
      if (r)
        return {
          count: r.targets.size,
          targets: e(Array.from(r.targets.values())),
          savedToYapd: r.savedToYapd
        };
    }
    return { count: 0, targets: [], savedToYapd: !1 };
  }
}
const f = new V();
function J() {
  var o;
  typeof chrome > "u" || !((o = chrome.webRequest) != null && o.onBeforeRequest) || chrome.webRequest.onBeforeRequest.addListener(
    (t) => {
      t.tabId <= 0 || t.url.startsWith("chrome-extension://") || h.getState().then((n) => {
        !n.activeInspectionEnabled || !n.paired || chrome.tabs.get(t.tabId, (e) => {
          if (chrome.runtime.lastError || !e || !e.url || L(e.url, n.settings.sensitiveUrlPatterns) || L(e.url, n.settings.hardBlockedUrlPatterns))
            return;
          const i = g(e.url);
          if (!i)
            return;
          const s = H(t.url, i, "web_request", {
            elementTag: t.type,
            initiatorScript: t.initiator
          });
          s && f.enqueue(
            {
              url: e.url,
              domain: i,
              title: e.title
            },
            s,
            t.tabId
          );
        });
      });
    },
    { urls: ["<all_urls>"] }
  );
}
console.log("[YAPD Sentinel] Service Worker iniciado.");
J();
function Q(o, t, n) {
  var i;
  const e = o.tab;
  if (e != null && e.url) {
    const s = g(e.url);
    if (s) {
      n({
        url: e.url,
        domain: s,
        title: e.title || (t == null ? void 0 : t.title)
      });
      return;
    }
  }
  if (e != null && e.id && typeof chrome < "u" && ((i = chrome.tabs) != null && i.get)) {
    chrome.tabs.get(e.id, (s) => {
      if (!chrome.runtime.lastError && (s != null && s.url)) {
        const r = g(s.url);
        if (r) {
          n({
            url: s.url,
            domain: r,
            title: s.title || (t == null ? void 0 : t.title)
          });
          return;
        }
      }
      n(t);
    });
    return;
  }
  n(t);
}
typeof chrome < "u" && chrome.runtime && (chrome.runtime.onInstalled.addListener(() => {
  console.log("[YAPD Sentinel] Extensão instalada/atualizada."), chrome.alarms.create("yapd_sentinel_sync_config", { periodInMinutes: 30 }), E.fetchConfig().catch(console.error);
}), chrome.alarms.onAlarm.addListener((o) => {
  o.name === "yapd_sentinel_sync_config" && E.fetchConfig().catch(console.error);
}), chrome.runtime.onMessage.addListener((o, t, n) => {
  var i, s;
  const e = (i = t.tab) == null ? void 0 : i.id;
  if (o.type === "CANDIDATE_DETECTED" || o.type === "PICKER_DETECTED") {
    const r = o.type === "PICKER_DETECTED";
    return h.getState().then((d) => {
      d.paired && (!r && !d.activeInspectionEnabled || Q(t, o.page, (c) => {
        var l;
        t.frameId && t.frameId !== 0 && (o.candidate.evidence = {
          ...o.candidate.evidence,
          frameUrl: t.url || ((l = o.page) == null ? void 0 : l.url)
        }), f.enqueue(c, o.candidate, e, r);
      }));
    }), n({ status: r ? "queued_immediate" : "queued" }), !0;
  }
  if (o.type === "GET_PAGE_SUMMARY") {
    const r = o.tabId || e, d = o.pageDomain || ((s = t.tab) != null && s.url ? g(t.tab.url) ?? void 0 : void 0), c = f.getPageSummary(d, r);
    return n(c), !0;
  }
  if (o.type === "SAVE_PAGE_ANALYSIS_TO_YAPD") {
    const r = o.tabId || e, d = o.pageDomain;
    return !r && !d ? (n({ success: !1, message: "Aba não identificada." }), !0) : (f.flushSession(r, d).then((c) => {
      n(c);
    }), !0);
  }
  if (o.type === "QUICK_BLOCK_TARGET") {
    const r = o.tabId || e;
    return h.getState().then(async (d) => {
      var y, w, D, k, C, P, $;
      if (!d.paired) {
        n({ success: !1, message: "Extensão desconectada." });
        return;
      }
      const l = f.getPageSummary((y = o.page) == null ? void 0 : y.domain, r).targets.find(
        (m) => m.target.toLowerCase() === o.target.toLowerCase()
      );
      let p = (w = o.page) == null ? void 0 : w.url, a = (D = o.page) == null ? void 0 : D.domain;
      if (!a || a === "unknown") {
        let m = t.tab;
        if (!m && r && typeof chrome < "u" && ((k = chrome.tabs) != null && k.get))
          try {
            m = await chrome.tabs.get(r);
          } catch {
          }
        if (!m && typeof chrome < "u" && ((C = chrome.tabs) != null && C.query))
          try {
            m = (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
          } catch {
          }
        m != null && m.url && (p = m.url, a = g(m.url) || void 0);
      }
      (!a || a === "unknown" || !a.includes(".")) && (a = u(o.target) || "sentinel.local", p = p || `https://${a}`);
      const A = {
        url: p || `https://${a}`,
        domain: a,
        title: ((P = o.page) == null ? void 0 : P.title) || (($ = t.tab) == null ? void 0 : $.title)
      }, T = await E.applyBlockTarget(
        o.target,
        A,
        l,
        o.kind || "exact"
      );
      T.success && f.markTargetAsBlocked(o.target, r), n(T);
    }), !0;
  }
  return !1;
}));
